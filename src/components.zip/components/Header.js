import React from 'react'
import fblogo from './fblogo.PNG';
import './Header.css';
import SearchIcon from '@material-ui/icons/Search';

function Header() {
    return (
    //   <div className="main_header">
    //     <div className="left_header">
    //         <img src={fblogo}/> 
    //      </div>
    //         <div className="middle_header">
    //         <SearchIcon /> 
    //         <input type="text"/>
    //         </div>
    //     </div>
    <div className="main_header" >
         <img className="logo" src={fblogo}/> 
         {/* <div className="search_icon">
         <SearchIcon /> 
        </div>
        <div className="middle_header"><input type="text"/></div> */}
        <p className="text">Login</p>
        <p className="text1">Register</p>
     </div>
     
    )
}

export default Header
