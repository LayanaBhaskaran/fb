import React from 'react'

function ErrorModel(props) {
    return (
        <div>
            <header>{props.title}</header>
        <body>{props.message}</body>
        

        </div>
    )
}

export default ErrorModel
