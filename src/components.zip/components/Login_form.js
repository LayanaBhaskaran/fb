import React from 'react'
import './Login_form.css';


//import '../../node_modules/bootstrap/dist/css/bootstrap.min.css';

function Login_form() {
    return (
        <div className="form">
            <form>
                
                    <div className="title-text">
                <h1>Log In</h1>
                <input type="text" required placeholder="Email address or username"/><br/>
                <input type="password" required placeholder="Password"/><br/>
                <button className="btn btn-success" type="submit">Log In</button>
                 <p>Don't have an account? 
                    </p>
                    </div>
                
            </form>
        </div>
    )
}

export default Login_form
