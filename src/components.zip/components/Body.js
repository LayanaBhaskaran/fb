import React from 'react'

function Body() {
    return (
        <div>
            <h1>welcome</h1>
        </div>
    )
}

export default Body
